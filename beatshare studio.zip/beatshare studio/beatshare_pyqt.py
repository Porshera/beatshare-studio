"""
BeatShare Studio v0.1-Demo
Зависимости: pip install PyQt6 pygame
Опционально:  pip install sounddevice soundfile  (для записи с микрофона)

Структура папок:
    assets/     — kick.wav, snare.wav, hat.wav, clap.wav, perc.wav
    projects/   — JSON-проекты (создаётся автоматически)
    recordings/ — WAV-записи  (создаётся автоматически)

Файлы можно класть прямо рядом со скриптом с именем вида assets_kick.wav —
скрипт найдёт их автоматически.
"""

import sys, os, json, base64, time, copy, hashlib

def resource_path(relative):
    try:
        base = sys._MEIPASS
    except Exception:
        base = os.path.abspath(".")
    return os.path.join(base, relative)

def recordings_path():
    """
    Путь к папке recordings рядом с exe или .py
    Всегда один и тот же — чтобы не было рассинхрона
    """
    if getattr(sys, 'frozen', False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))

    return os.path.join(base, "recordings")

def app_base_path():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def projects_path():
    path = os.path.join(app_base_path(), "projects")
    os.makedirs(path, exist_ok=True)
    return path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSlider, QLineEdit, QComboBox, QGroupBox,
    QFileDialog, QTabWidget, QSpinBox, QTextEdit, QMessageBox,
    QProgressBar, QDialog, QListWidget,
)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal

os.chdir(os.path.dirname(os.path.abspath(__file__)))

# ── КОНФИГУРАЦИЯ ──────────────────────────────────────────────────────────────

# (имя трека, цвет кнопок, имя wav-файла)
TRACKS = [
    ("Kick",  "#3b82f6", "kick.wav"),
    ("Snare", "#ef4444", "snare.wav"),
    ("Hat",   "#facc15", "hat.wav"),
    ("Clap",  "#22c55e", "clap.wav"),
    ("Perc",  "#a855f7", "perc.wav"),
]
TRACK_NAMES = [t for t, _, _ in TRACKS]

STEPS       = 16
DEFAULT_BPM = 120

# Готовые паттерны
PRESETS = {
    "House": {
        "Kick":  [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,0],
        "Snare": [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "Hat":   [0,0,1,0, 0,0,1,0, 0,0,1,0, 0,0,1,0],
        "Clap":  [0]*16, "Perc": [0]*16,
    },
    "Trap": {
        "Kick":  [1,0,0,0, 0,0,0,1, 0,0,1,0, 0,0,0,0],
        "Snare": [0]*16,
        "Hat":   [1,0,1,0, 1,0,1,0, 1,0,1,0, 1,0,1,0],
        "Clap":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "Perc":  [0]*16,
    },
    "LoFi": {
        "Kick":  [1,0,0,0, 0,0,0,0, 1,0,0,0, 0,0,0,0],
        "Snare": [0]*16,
        "Hat":   [0,0,0,1, 0,0,1,0, 0,0,0,1, 0,0,1,0],
        "Clap":  [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
        "Perc":  [0,0,0,1, 0,0,0,0, 0,0,0,1, 0,0,0,0],
    },
}

TIPS = [
    "💡 Нажми ✨ Demo, чтобы загрузить готовый паттерн!",
    "💡 Shift ⬅ ➡ смещает весь паттерн на шаг.",
    "💡 📤 Поделиться — скопирует полный код для друга.",
    "💡 BPM можно менять прямо во время воспроизведения.",
    "💡 Кнопка M заглушает отдельный трек.",
    "💡 Двойной клик по записи в списке → загрузить в лупер.",
]

# ── ПОИСК АУДИОФАЙЛОВ ─────────────────────────────────────────────────────────

def find_asset(filename: str) -> str:
    """
    Ищет wav-файл в нескольких местах (включая PyInstaller):

      1. resource_path("assets/<filename>") — внутри .exe (PyInstaller)
      2. <cwd>/assets/<filename>            — папка рядом с exe (основной вариант)
      3. assets/<filename>                  — стандартный путь при запуске .py
      4. <filename>                         — файл прямо рядом

    Возвращает первый найденный путь.
    Если файл не найден — возвращает исходное имя (и пишет в консоль).
    """
    base = os.path.dirname(sys.executable if getattr(sys, 'frozen', False) else __file__)

    candidates = [
        os.path.join(base, "assets", filename),   # рядом с exe
        os.path.join(os.getcwd(), "assets", filename),
        os.path.join("assets", filename),
        filename,
    ]

    for p in candidates:
        if os.path.exists(p):
            return p

    print("ASSET NOT FOUND:", filename)
    return None


# ── ИНИЦИАЛИЗАЦИЯ ЗВУКА ───────────────────────────────────────────────────────
# Вызывается ПОСЛЕ QApplication() — на Windows pygame.mixer может конфликтовать
# с аудио-драйвером, если инициализировать его раньше Qt.

# SDL_AUDIODRIVER нужно выставить ДО импорта pygame — критично для PyInstaller
os.environ.setdefault('SDL_AUDIODRIVER', 'directsound')

import pygame        # noqa: E402
import pygame.mixer  # явный импорт — PyInstaller иначе может не упаковать модуль

# Хранилища аудио:
sounds   = {}   # {имя_трека: pygame.mixer.Sound}
channels = {}   # {имя_трека: pygame.mixer.Channel} — отдельный канал на трек

def init_audio():
    """Инициализирует mixer и загружает сэмплы. Пропускает отсутствующие файлы."""
    # Сбрасываем предыдущий стейт если есть
    try:
        if pygame.mixer.get_init():
            pygame.mixer.quit()
        if pygame.get_init():
            pygame.quit()
    except Exception:
        pass

    # Инициализируем pygame целиком
    pygame.init()

    # Инициализируем mixer (fallback без параметров если directsound не поднялся)
    try:
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=1024)
    except Exception:
        pygame.mixer.init()

    pygame.mixer.set_num_channels(16)
    print(f"[audio] Mixer инициализирован: {pygame.mixer.get_init()}")

    for name, _, filename in TRACKS:

        if filename.startswith("recordings"):
            path = filename
        else:
            path = find_asset(filename)

        print("LOAD TRY:", name, path)

        if not path or not os.path.exists(path):
            print(f"[audio] ✗ {name}: файл не найден ({filename})")
            continue

        try:
            snd = pygame.mixer.Sound(path)
            sounds[name] = snd

            ch_index = len(channels)
            pygame.mixer.set_num_channels(max(16, ch_index + 1))
            channels[name] = pygame.mixer.Channel(ch_index)

            print(f"[audio] ✓ {name} ← {path}")

        except Exception as e:
            print(f"[audio] ✗ {name}: {e}")

# ── ПОТОК ЗАПИСИ МИКРОФОНА ────────────────────────────────────────────────────

class RecordThread(QThread):
    done  = pyqtSignal(str)   # путь к сохранённому файлу
    error = pyqtSignal(str)   # сообщение об ошибке

    def __init__(self, duration=5, sr=44100):
        super().__init__()
        self.duration = duration
        self.sr = sr

    def run(self):
        try:
            import sounddevice as sd
            import soundfile as sf
            audio = sd.rec(int(self.sr * self.duration),
                           samplerate=self.sr, channels=1, dtype="float32")
            sd.wait()
            rec_dir = recordings_path()
            os.makedirs(rec_dir, exist_ok=True)

            path = os.path.join(rec_dir, f"sample_{int(time.time())}.wav")
            sf.write(path, audio, self.sr)
            print("[record] saved to:", path)
            self.done.emit(path)
        except ImportError:
            self.error.emit("Установи: pip install sounddevice soundfile")
        except Exception as e:
            self.error.emit(str(e))

# ── ВСПОМОГАТЕЛЬНЫЕ ДИАЛОГИ ───────────────────────────────────────────────────

DARK = "background:#1e293b; color:white; font:10pt 'Segoe UI';"

class TagDialog(QDialog):
    """Редактирование тегов проекта (список через запятую)."""
    def __init__(self, tags, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Теги проекта")
        self.setFixedSize(360, 140)
        self.setStyleSheet(DARK)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Теги через запятую (напр.: lofi, dark, minimal):"))
        self.edit = QLineEdit(", ".join(tags))
        self.edit.setStyleSheet("background:#0f172a; border-radius:6px; padding:6px;")
        lay.addWidget(self.edit)
        row = QHBoxLayout()
        for txt, fn, bg in [("✓ Сохранить", self.accept, "#2563eb"),
                             ("Отмена",      self.reject, "#374151")]:
            b = QPushButton(txt)
            b.setStyleSheet(f"background:{bg}; border-radius:6px; padding:8px; color:white;")
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)

    def get_tags(self):
        return [t.strip() for t in self.edit.text().split(",") if t.strip()]


class ShareDialog(QDialog):
    """
    Диалог «Поделиться паттерном».
    Показывает полный base64-код, который можно скопировать или сохранить в файл.
    Получатель вставляет этот код в поле импорта — никаких промежуточных серверов.
    """
    def __init__(self, code: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("📤 Поделиться паттерном")
        self.resize(520, 320)
        self.setStyleSheet(DARK)
        self._code = code

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(
            "Скопируй весь код ниже и отправь другу.\n"
            "Друг вставляет его в поле «Загрузить по коду»."
        ))

        self.text = QTextEdit()
        self.text.setReadOnly(True)
        self.text.setPlainText(code)
        self.text.setStyleSheet(
            "background:#0f172a; border-radius:6px; padding:6px; "
            "font-family:Consolas,monospace; font-size:9pt;"
        )
        lay.addWidget(self.text)

        row = QHBoxLayout()
        for txt, fn, bg in [
            ("📋 Копировать в буфер", self._copy,    "#2563eb"),
            ("💾 Сохранить в файл",   self._save,    "#7c3aed"),
            ("Закрыть",               self.accept,   "#374151"),
        ]:
            b = QPushButton(txt)
            b.setStyleSheet(f"background:{bg}; border-radius:6px; padding:8px; color:white;")
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)

    def _copy(self):
        QApplication.clipboard().setText(self._code)

    def _save(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить код", "beatshare_share.txt", "Text (*.txt)"
        )
        if path:
            with open(path, "w") as f:
                f.write(self._code)


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Справка BeatShare")
        self.resize(460, 400)
        self.setStyleSheet(DARK)
        lay = QVBoxLayout(self)
        t = QTextEdit()
        t.setReadOnly(True)
        t.setStyleSheet("background:#0f172a; border:none; padding:10px;")
        t.setHtml("""
<h2 style='color:#60a5fa'>🎵 BeatShare Studio</h2>
<h3 style='color:#facc15'>Секвенсор</h3>
<p>Клик на ячейку — включить/выключить удар. ▶ Play / ⏹ Stop. ✨ Demo — загрузить пресет.</p>
<h3 style='color:#facc15'>Поделиться паттерном</h3>
<p>📤 <b>Поделиться</b> — открывает окно с полным кодом паттерна.<br>
Скопируй его и отправь другу любым способом (чат, почта, файл).<br>
Друг вставляет код в поле <b>Загрузить по коду</b> → нажимает кнопку.</p>
<h3 style='color:#facc15'>Запись и лупер</h3>
<p>Вкладка «Лупер»: записать звук с микрофона или зациклить WAV поверх бита.<br>
<code>pip install sounddevice soundfile</code></p>
        """)
        lay.addWidget(t)
        b = QPushButton("Закрыть")
        b.setStyleSheet("background:#2563eb; border-radius:6px; padding:8px; color:white;")
        b.clicked.connect(self.accept)
        lay.addWidget(b)

# ── ГЛАВНОЕ ОКНО ──────────────────────────────────────────────────────────────

class BeatShare(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("BeatShare Studio v0.1-Demo")
        self.resize(1400, 800)

        # Паттерн: {трек: [0/1 × STEPS]}
        self.data    = {t: [0]*STEPS for t in TRACK_NAMES}
        self.muted   = {t: False for t in TRACK_NAMES}
        self.history = []        # стек undo (≤50 снимков)
        self.step    = 0         # текущий шаг воспроизведения
        self.playing = False
        self.tags    = []

        self.loop_sound    = None   # pygame.mixer.Sound лупера
        # Пользовательские треки [{name, color, path, sound, channel}]
        self.custom_tracks = []
        self._custom_colors = ["#f97316","#06b6d4","#84cc16","#ec4899",
                                "#8b5cf6","#14b8a6","#f59e0b","#fb923c"]

        # Таймер секвенсора: срабатывает каждый шаг (интервал зависит от BPM)
        self.timer = QTimer()
        self.timer.timeout.connect(self._tick)

        # Таймер смены подсказок
        self.tip_idx = 0
        tip_t = QTimer(self)
        tip_t.timeout.connect(self._next_tip)
        tip_t.start(8000)

        self._apply_styles()
        self._build_ui()

    def _btn(self, text, slot=None, style=""):
        b = QPushButton(text)
        if style:
            b.setStyleSheet(style)
        if slot:
            b.clicked.connect(slot)

        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        return b

    def edit_tags(self):
        dlg = TagDialog(self.tags, self)
        if dlg.exec():
            self.tags = dlg.get_tags()
            self._update_tags()

    # ── СТИЛИ ─────────────────────────────────────────────────────────────────

    def _apply_styles(self):
        self.setStyleSheet("""
        QMainWindow, QWidget {
            background:#0b1120; color:#e2e8f0;
            font-family:'Segoe UI',sans-serif; font-size:10pt;
        }
        QGroupBox {
            background:#111827; border:1px solid #1e2d45; border-radius:10px;
            margin-top:8px; padding:10px; font-weight:bold; color:#94a3b8;
        }
        QGroupBox::title { subcontrol-origin:margin; left:10px; top:2px; }
        QPushButton {
            background:#1e3a5f; border:1px solid #2563eb44;
            color:#93c5fd; border-radius:7px; padding:6px 12px; font-weight:500;
        }
        QPushButton:hover   { background:#2563eb; color:white; }
        QPushButton:pressed { background:#1d4ed8; }
        QLineEdit, QComboBox, QSpinBox {
            background:#0f172a; border:1px solid #1e3a5f;
            border-radius:7px; padding:6px 10px; color:#e2e8f0;
        }
        QSlider::groove:horizontal { height:4px; background:#1e3a5f; border-radius:2px; }
        QSlider::handle:horizontal {
            background:#3b82f6; width:14px; height:14px; margin:-5px 0; border-radius:7px;
        }
        QTabWidget::pane { border:1px solid #1e2d45; border-radius:8px; background:#111827; }
        QTabBar::tab {
            background:#0f172a; color:#64748b;
            border-radius:6px 6px 0 0; padding:6px 16px; margin-right:2px;
        }
        QTabBar::tab:selected { background:#111827; color:#60a5fa; border-bottom:2px solid #3b82f6; }
        QScrollBar:vertical   { background:#0f172a; width:8px; border-radius:4px; }
        QScrollBar::handle:vertical { background:#1e3a5f; border-radius:4px; }
        """)

    # ── ПОСТРОЕНИЕ UI ─────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        lay = QHBoxLayout(root)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(10)
        lay.addWidget(self._panel_left(),  1)
        lay.addWidget(self._panel_right(), 4)

    def _next_tip(self):
        self.tip_idx = (self.tip_idx + 1) % len(TIPS)
        self.tipLabel.setText(TIPS[self.tip_idx])

    # ── ЛЕВАЯ ПАНЕЛЬ ──────────────────────────────────────────────────────────

    def _panel_left(self):
        w = QWidget(); w.setMaximumWidth(260)
        lay = QVBoxLayout(w); lay.setSpacing(8)

        lbl = QLabel("🎵 BeatShare")
        lbl.setStyleSheet("font-size:18pt; font-weight:bold; color:#60a5fa; padding:4px 0;")
        lay.addWidget(lbl)
        lay.addWidget(QLabel("v0.1-Demo"))

        # Проект
        g = QGroupBox("📁 Проект"); gl = QVBoxLayout()
        self.projectName = QLineEdit("Untitled")
        self.tagLabel    = QLabel("")
        self.tagLabel.setStyleSheet("color:#94a3b8; font-size:9pt;")
        self.tagLabel.setWordWrap(True)
        for w_ in [QLabel("Название:"), self.projectName, self.tagLabel,
                   self._btn("🏷 Теги",      self.edit_tags),
                   self._btn("💾 Сохранить", self.save_project),
                   self._btn("📂 Загрузить", self.load_project)]:
            gl.addWidget(w_)
        g.setLayout(gl); lay.addWidget(g)

        # Громкость
        g2 = QGroupBox("🔊 Громкость"); vl = QVBoxLayout()
        self.masterVol = self._slider(80)   # master — общий множитель
        vl.addWidget(QLabel("Master")); vl.addWidget(self.masterVol)
        self.trackVol = {}
        for t, _, _ in TRACKS:
            row = QHBoxLayout()
            lb  = QLabel(t); lb.setFixedWidth(40)
            s   = self._slider(80)
            row.addWidget(lb); row.addWidget(s)
            self.trackVol[t] = s; vl.addLayout(row)
        self._vol_layout = vl          # ← нужен для динамических треков
        g2.setLayout(vl); lay.addWidget(g2)

        # Совместная работа
        g3 = QGroupBox("🤝 Совместная работа"); cl = QVBoxLayout()
        # Кнопка «Поделиться» открывает ShareDialog с полным кодом
        cl.addWidget(self._btn("📤 Поделиться паттерном", self._share_dialog,
                               "background:#0f4c81;"))
        cl.addWidget(QLabel("Загрузить код друга:"))
        self.importCode = QLineEdit(); self.importCode.setPlaceholderText("Вставь код сюда...")
        cl.addWidget(self.importCode)
        cl.addWidget(self._btn("📥 Загрузить по коду", self.import_project))
        g3.setLayout(cl); lay.addWidget(g3)

        lay.addWidget(self._btn("❓ Справка", lambda: HelpDialog(self).exec()))
        lay.addStretch()

        self.tipLabel = QLabel(TIPS[0])
        self.tipLabel.setWordWrap(True)
        self.tipLabel.setStyleSheet("color:#64748b; font-size:9pt; padding:4px;")
        lay.addWidget(self.tipLabel)
        return w

    # ── ПРАВАЯ ПАНЕЛЬ ─────────────────────────────────────────────────────────

    def _panel_right(self):
        w = QWidget(); lay = QVBoxLayout(w); lay.setSpacing(8)

        # Транспорт
        top = QHBoxLayout(); top.setSpacing(6)
        self.playBtn = self._btn("▶ Play", self.play,
                                 "background:#16a34a; color:white; font-weight:bold; padding:8px 18px;")
        top.addWidget(self.playBtn)
        top.addWidget(self._btn("⏹ Stop",   self.stop))
        top.addWidget(self._btn("✨ Demo",   self.demo))
        top.addWidget(self._btn("↩ Undo",   self.undo))
        top.addWidget(self._btn("⬅",        self.shift_left))
        top.addWidget(self._btn("➡",        self.shift_right))
        top.addWidget(self._btn("🧹 Clear", self.clear))

        top.addWidget(QLabel("Стиль:"))
        self.styleBox = QComboBox(); self.styleBox.addItems(list(PRESETS.keys()))
        top.addWidget(self.styleBox)

        top.addWidget(QLabel("BPM:"))
        self.bpmSpin = QSpinBox()
        self.bpmSpin.setRange(60, 220); self.bpmSpin.setValue(DEFAULT_BPM)
        self.bpmSpin.setFixedWidth(64)
        self.bpmSpin.valueChanged.connect(
            lambda bpm: self.timer.setInterval(self._bpm_ms(bpm)) if self.playing else None
        )
        top.addWidget(self.bpmSpin); top.addStretch()
        lay.addLayout(top)

        tabs = QTabWidget()
        tabs.addTab(self._tab_sequencer(), "🥁 Секвенсор")
        tabs.addTab(self._tab_looper(),    "🔁 Лупер / Запись")
        lay.addWidget(tabs)

        self.statusBar = QLabel("Готово — нажми ▶ Play чтобы начать!")
        self.statusBar.setStyleSheet("color:#64748b; padding:4px 8px;")
        lay.addWidget(self.statusBar)
        return w

    # ── СЕКВЕНСОР ─────────────────────────────────────────────────────────────

    def _tab_sequencer(self):
        BTN, GAP, BIG = 46, 5, 10   # размер кнопки, зазор, разделитель каждые 4

        w = QWidget(); lay = QVBoxLayout(w)
        lay.setContentsMargins(12, 12, 12, 12); lay.setSpacing(0)

        # Нумерация шагов (stub шире: имя(45)+sp(8)+M(28)+X(24)+sp(4) = 109)
        hdr = QHBoxLayout(); hdr.setSpacing(0)
        stub = QWidget(); stub.setFixedWidth(109)
        hdr.addWidget(stub)
        for c in range(STEPS):
            if c and c % 4 == 0: hdr.addSpacing(BIG)
            n = QLabel(str(c+1)); n.setFixedWidth(BTN)
            n.setAlignment(Qt.AlignmentFlag.AlignCenter)
            n.setStyleSheet("color:#334155; font-size:8pt;")
            hdr.addWidget(n)
        hdr.addStretch(); lay.addLayout(hdr)

        self.buttons = {}; self.muteButtons = {}

        for t, col, _ in TRACKS:
            lay.addLayout(self._make_track_row(t, col, BTN, GAP, BIG))

        self._seq_lay = lay          # ← для вставки строк пользовательских треков
        self._seq_stretch_idx = lay.count()   # индекс финального stretch
        lay.addStretch(); self._render(); return w

    # ── ЛУПЕР / ЗАПИСЬ ────────────────────────────────────────────────────────

    def _make_track_row(self, t, col, BTN=46, GAP=5, BIG=10, removable=False):
        """Строит QHBoxLayout одного трека секвенсора. Регистрирует кнопки."""
        row = QHBoxLayout(); row.setSpacing(0)
        row.setContentsMargins(0, GAP, 0, GAP)

        lb = QLabel(t); lb.setFixedWidth(45)
        lb.setStyleSheet(f"color:{col}; font-weight:bold; font-size:{'9' if removable else '10'}pt;")
        row.addWidget(lb); row.addSpacing(8)

        m = QPushButton("M"); m.setFixedSize(28, BTN); m.setCheckable(True)
        m.setStyleSheet("padding:0; font-size:8pt; border-radius:5px;")
        m.toggled.connect(lambda on, tt=t: self._mute(tt, on))
        row.addWidget(m); self.muteButtons[t] = m

        if removable:
            x = QPushButton("✕"); x.setFixedSize(24, BTN)
            x.setStyleSheet("padding:0;font-size:8pt;border-radius:5px;color:#ef4444;background:#1e293b;")
            x.clicked.connect(lambda _, tt=t: self._remove_custom_track(tt))
            row.addWidget(x)
        else:
            sp = QWidget(); sp.setFixedWidth(24); row.addWidget(sp)

        self.buttons[t] = []
        for c in range(STEPS):
            if c and c % 4 == 0: row.addSpacing(BIG)
            b = QPushButton(); b.setFixedSize(BTN, BTN)
            b.clicked.connect(lambda _, tt=t, cc=c: self._toggle(tt, cc))
            b.setToolTip(f"{t} — шаг {c+1}")
            row.addWidget(b)
            if c < STEPS-1: row.addSpacing(GAP)
            self.buttons[t].append(b)
        row.addStretch()
        return row

    def _tab_looper(self):
        w = QWidget(); lay = QVBoxLayout(w)

        # Запись с микрофона
        g = QGroupBox("🎙 Запись с микрофона"); gl = QVBoxLayout()
        self.recDuration = QSpinBox(); self.recDuration.setRange(1, 30); self.recDuration.setValue(5)
        dr = QHBoxLayout(); dr.addWidget(QLabel("Длительность (сек):")); dr.addWidget(self.recDuration)
        gl.addLayout(dr)
        self.recBtn = self._btn("● Начать запись", self._record,
                                "background:#dc2626; color:white; font-weight:bold; padding:10px;")
        self.recProgress = QProgressBar(); self.recProgress.setRange(0,100); self.recProgress.setVisible(False)
        gl.addWidget(self.recBtn); gl.addWidget(self.recProgress)
        g.setLayout(gl); lay.addWidget(g)

        # Лупер — зациклить WAV поверх бита
        g2 = QGroupBox("🔁 Лупер"); ll = QVBoxLayout()
        self.loopFile = QLineEdit(); self.loopFile.setPlaceholderText("Путь к аудиофайлу...")
        self.loopVol  = self._slider(70)
        self.loopVol.valueChanged.connect(
            lambda v: self.loop_sound.set_volume(v/100) if self.loop_sound else None
        )
        startBtn = self._btn("▶ Зациклить", self._loop_start,
                             "background:#7c3aed; color:white; padding:8px;")
        for w_ in [QLabel("Файл:"), self.loopFile,
                   self._btn("📂 Выбрать файл", self._loop_browse),
                   QLabel("Громкость лупа:"), self.loopVol,
                   startBtn, self._btn("⏹ Стоп лупер", self._loop_stop)]:
            ll.addWidget(w_)
        g2.setLayout(ll); lay.addWidget(g2)

        # Список записей
        g3 = QGroupBox("🗂 Записанные файлы"); fl = QVBoxLayout()
        self.fileList = QListWidget()
        self.fileList.setStyleSheet("background:#0f172a; border-radius:6px;")
        self.fileList.itemDoubleClicked.connect(
            lambda item: self.loopFile.setText(os.path.join(recordings_path(), item.text()))
        )
        fl.addWidget(self.fileList)
        fl.addWidget(self._btn("🔄 Обновить список", self._refresh_files))
        fl.addWidget(self._btn(
            "➕ Добавить в секвенсор", self._sample_to_seq,
            "background:#0d4f3c; color:#4ade80; font-weight:bold; padding:8px;"
        ))
        g3.setLayout(fl); lay.addWidget(g3)

        self._refresh_files(); return w

    # ── ПОЛЬЗОВАТЕЛЬСКИЕ СЭМПЛЫ В СЕКВЕНСОРЕ ────────────────────────────────

    def _sample_to_seq(self):
        """Загружает WAV из поля лупера как новый трек секвенсора."""
        path = self.loopFile.text().strip()
        if not path or not os.path.exists(path):
            self._status("❌ Сначала выбери файл в поле лупера"); return

        # Уникальное короткое имя
        name = os.path.splitext(os.path.basename(path))[0][:9]
        TRACKS.append((name, "#888888", path))  # новый трек
        TRACK_NAMES.append(name)               # имя для UI
        existing = set(TRACK_NAMES) | {ct["name"] for ct in self.custom_tracks}
        base, idx = name, 2
        while name in existing: name = f"{base}{idx}"; idx += 1

        try:
            snd = pygame.mixer.Sound(path)
        except Exception as e:
            self._status(f"❌ Не удалось загрузить: {e}"); return

        # Резервируем новый канал
        ch_idx = len(sounds) + len(self.custom_tracks)
        if ch_idx >= pygame.mixer.get_num_channels():
            pygame.mixer.set_num_channels(ch_idx + 8)
        ch  = pygame.mixer.Channel(ch_idx)
        col = self._custom_colors[len(self.custom_tracks) % len(self._custom_colors)]

        ct = dict(name=name, color=col, path=path, sound=snd, channel=ch)
        self.custom_tracks.append(ct)
        self.data[name]  = [0] * STEPS
        self.muted[name] = False

        # Строка в секвенсоре — вставляем перед финальным stretch
        row = self._make_track_row(name, col, removable=True)
        # вставляем перед stretch
        self._seq_lay.insertLayout(self._seq_stretch_idx, row)

        # обновляем индекс stretch (он сдвинулся вниз)
        self._seq_stretch_idx += 1

        ct["row_layout"] = row 

        # Слайдер громкости в левой панели
        rl = QHBoxLayout()
        lb = QLabel(name); lb.setFixedWidth(40)
        lb.setStyleSheet(f"color:{col}; font-size:8pt;")
        s  = self._slider(80); self.trackVol[name] = s
        rl.addWidget(lb); rl.addWidget(s)
        self._vol_layout.addLayout(rl)

        self._render()
        self._status(f"✅ Добавлен трек «{name}» ← {os.path.basename(path)}")

        ct["vol_layout"] = rl

    def _remove_custom_track(self, name):
        """Полностью удаляет пользовательский трек (UI + данные)."""

        # подтверждение
        if QMessageBox.question(
            self,
            "Удалить?",
            f"Удалить трек «{name}»?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        ) != QMessageBox.StandardButton.Yes:
            return

        ct = next((c for c in self.custom_tracks if c["name"] == name), None)
        if not ct:
            return

        # --- ОСТАНОВИТЬ КАНАЛ ---
        ch = ct.get("channel")
        if ch:
            ch.stop()

        # --- УДАЛЯЕМ СТРОКУ СЕКВЕНСОРА ---
        row = ct.get("row_layout")
        if row:
            while row.count():
                item = row.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()
            self._seq_lay.removeItem(row)

        # --- УДАЛЯЕМ СТРОКУ ГРОМКОСТИ ---
        vol = ct.get("vol_layout")
        if vol:
            while vol.count():
                item = vol.takeAt(0)
                w = item.widget()
                if w:
                    w.deleteLater()
            self._vol_layout.removeItem(vol)

        # --- УДАЛЯЕМ ДАННЫЕ ---
        self.custom_tracks.remove(ct)
        self.data.pop(name, None)
        self.muted.pop(name, None)
        self.buttons.pop(name, None)
        self.muteButtons.pop(name, None)
        self.trackVol.pop(name, None)

        self._seq_stretch_idx = self._seq_lay.count() - 1

        self._render()
        self._status(f"🗑 Трек «{name}» удалён")

    # ── ЛОГИКА СЕКВЕНСОРА ─────────────────────────────────────────────────────

    def _snapshot(self):
        """Сохраняет снимок паттерна в стек undo."""
        self.history.append(copy.deepcopy(self.data))
        if len(self.history) > 50: self.history.pop(0)

    def _toggle(self, track, col):
        self._snapshot()

        # переключаем шаг
        self.data[track][col] ^= 1

        # 🔊 звук при клике (опционально, но круто)
        if self.data[track][col] and track in sounds:
            sounds[track].play()

        # 🔥 ОБЯЗАТЕЛЬНО — перерисовка
        self._render()


    def _mute(self, track, on):
        """Переключает mute; перекрашивает кнопку M."""
        self.muted[track] = on
        self.muteButtons[track].setStyleSheet(
            "padding:0;font-size:8pt;border-radius:5px;"
            + ("background:#dc2626;color:white;" if on else "")
        )

    def _render(self):
        """Перерисовывает все ячейки сетки по текущему состоянию."""
        clr = {t: c for t, c, _ in TRACKS}
        clr.update({ct["name"]: ct["color"] for ct in self.custom_tracks})
        for t, row in self.buttons.items():
            if t not in self.data: continue
            for i, btn in enumerate(row):
                active = self.data[t][i]
                cur = (i == self.step and self.playing)
                col_t  = clr.get(t, "#60a5fa")
                if active:
                    bg = col_t
                    border = "border:2px solid #ffffff;" if cur else "border:2px solid transparent;"
                else:
                    bg = "#1e293b"
                    border = "border:1px solid #334155;"
                btn.setStyleSheet(f"background:{bg};border-radius:7px;{border}")

    def _bpm_ms(self, bpm):
        """BPM → интервал таймера в мс (16-е ноты)."""
        return int(60_000 / bpm / 4)

    def _tick(self):
        master = self.masterVol.value() / 100

        # --- Стандартные треки ---
        for t, _, _ in TRACKS:
            steps = self.data.get(t)

            if (
                steps
                and len(steps) > self.step
                and steps[self.step]
                and not self.muted.get(t)
                and t in sounds
            ):
                vol = self.trackVol[t].value() / 100
                sounds[t].set_volume(master * vol)

                ch = channels.get(t)
                if ch:
                    ch.play(sounds[t])
                else:
                    sounds[t].play()

        # --- Пользовательские треки ---
        for ct in list(self.custom_tracks):  # копия списка
            n = ct.get("name")
            steps = self.data.get(n)

            if (
                n
                and steps
                and len(steps) > self.step
                and steps[self.step]
                and not self.muted.get(n)
            ):
                vol = self.trackVol.get(n)
                v = (vol.value() / 100 if vol else 1.0) * master

                snd = ct.get("sound")
                ch  = ct.get("channel")

                if snd and ch:
                    snd.set_volume(v)
                    ch.play(snd)

        self.step = (self.step + 1) % STEPS
        self._render()

    def play(self):
        self.playing = True
        self.timer.start(self._bpm_ms(self.bpmSpin.value()))
        self.playBtn.setStyleSheet(
            "background:#15803d;color:white;font-weight:bold;padding:8px 20px;")
        self._status("▶ Воспроизведение...")

    def stop(self):
        self.playing = False; self.timer.stop(); self.step = 0; self._render()
        self.playBtn.setStyleSheet(
            "background:#16a34a;color:white;font-weight:bold;padding:8px 18px;")
        self._status("⏹ Остановлено")

    def clear(self):
        self._snapshot()
        for k in self.data: self.data[k] = [0] * STEPS
        self._render()

    def demo(self):
        """Загружает выбранный пресет."""
        self._snapshot()
        preset = PRESETS.get(self.styleBox.currentText(), {})
        for t in TRACK_NAMES:
            self.data[t] = list(preset.get(t, [0]*STEPS))
        self._render(); self._status(f"✨ {self.styleBox.currentText()}")

    def undo(self):
        if self.history:
            self.data = self.history.pop(); self._render(); self._status("↩ Отменено")

    def shift_left(self):
        self._snapshot()
        for k in self.data: self.data[k] = self.data[k][1:] + self.data[k][:1]
        self._render()

    def shift_right(self):
        self._snapshot()
        for k in self.data: self.data[k] = self.data[k][-1:] + self.data[k][:-1]
        self._render()

    # ── СОВМЕСТНАЯ РАБОТА ─────────────────────────────────────────────────────

    def _encode(self) -> str:
        """Кодирует текущий паттерн + BPM + название + теги в base64-строку."""
        payload = {
            "data": self.data, "bpm": self.bpmSpin.value(),
            "name": self.projectName.text(), "tags": self.tags,
        }
        return base64.urlsafe_b64encode(
            json.dumps(payload, separators=(",", ":")).encode()
        ).decode()

    def _share_dialog(self):
        """
        Открывает окно ShareDialog с полным кодом паттерна.
        В отличие от старого подхода (BS-XXXXXXXX), здесь передаётся ВЕСЬ код —
        получатель может вставить его напрямую, без промежуточного сервера.
        """
        ShareDialog(self._encode(), self).exec()

    def import_project(self):
        """Декодирует код из поля ввода и восстанавливает паттерн."""
        code = self.importCode.text().strip()
        if not code:
            self._status("❌ Поле пустое"); return
        try:
            p = json.loads(base64.urlsafe_b64decode(code.encode()).decode())
            self.data = p["data"]; self.bpmSpin.setValue(p.get("bpm", DEFAULT_BPM))
            self.projectName.setText(p.get("name", "Untitled"))
            self.tags = p.get("tags", []); self._update_tags(); self._render()
            self._status("📥 Паттерн загружен!")
        except Exception as e:
            self._status(f"❌ Неверный код: {e}")

    # ── ПРОЕКТ (сохранение / загрузка) ───────────────────────────────────────

    def save_project(self):
        try:
            name = self.projectName.text() or "untitled"

            path = os.path.join(projects_path(), name + ".json")

            os.makedirs(projects_path(), exist_ok=True)

            data = {
                "name": name,
                "bpm": self.bpmSpin.value(),
                "tags": self.tags,
                "data": self.data
            }

            with open(path, "w", encoding="utf8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

            self._status(f"💾 Сохранено: {path}")

        except Exception as e:
            import traceback
            print(traceback.format_exc())
            self._status(f"❌ Ошибка сохранения: {e}")

    def load_project(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Открыть проект",
            projects_path(),
            "*.json"
        )
        if not path: return
        with open(path, encoding="utf8") as f: p = json.load(f)
        self.data = p.get("data", {t: [0]*STEPS for t in TRACK_NAMES})
        self.bpmSpin.setValue(p.get("bpm", DEFAULT_BPM))
        self.projectName.setText(p.get("name", "Untitled"))
        self.tags = p.get("tags", []); self._update_tags(); self._render()
        self._status(f"📂 {os.path.basename(path)}")

    # ── ТЕГИ ──────────────────────────────────────────────────────────────────

    def edit_tags(self):
        dlg = TagDialog(self.tags, self)
        if dlg.exec(): self.tags = dlg.get_tags(); self._update_tags()

    def _update_tags(self):
        self.tagLabel.setText("🏷 " + " ".join(f"#{t}" for t in self.tags) if self.tags else "")

    # ── ЗАПИСЬ МИКРОФОНА ──────────────────────────────────────────────────────

    def _record(self):
        dur = self.recDuration.value()
        self.recBtn.setEnabled(False); self.recBtn.setText("⏳ Запись...")
        self.recProgress.setVisible(True); self.recProgress.setValue(0)
        self._rec_t = 0
        self._rec_timer = QTimer(self); self._rec_timer.timeout.connect(
            lambda: (setattr(self, '_rec_t', self._rec_t + 0.1),
                     self.recProgress.setValue(min(int(self._rec_t/dur*100), 99)))
        ); self._rec_timer.start(100)
        self._rec_thread = RecordThread(duration=dur)
        self._rec_thread.done.connect(self._rec_done)
        self._rec_thread.error.connect(self._rec_err)
        self._rec_thread.start()

    def _rec_done(self, path):
        self._rec_timer.stop(); self.recProgress.setValue(100); self.recProgress.setVisible(False)
        self.recBtn.setEnabled(True); self.recBtn.setText("● Начать запись")
        self.loopFile.setText(path); self._refresh_files(); self._status(f"🎙 {path}")

    def _rec_err(self, msg):
        self._rec_timer.stop(); self.recProgress.setVisible(False)
        self.recBtn.setEnabled(True); self.recBtn.setText("● Начать запись")
        self._status(f"❌ {msg}")
        QMessageBox.warning(self, "Ошибка", f"{msg}\n\npip install sounddevice soundfile")

    # ── ЛУПЕР ─────────────────────────────────────────────────────────────────

    def _loop_browse(self):
        p, _ = QFileDialog.getOpenFileName(self, "Файл", "", "Audio (*.wav *.ogg)")
        if p: self.loopFile.setText(p)

    def _loop_start(self):
        path = self.loopFile.text()
        if not path or not os.path.exists(path):
            self._status("❌ Файл не найден"); return
        self._loop_stop()
        try:
            self.loop_sound = pygame.mixer.Sound(path)
            self.loop_sound.set_volume(self.loopVol.value() / 100)
            self.loop_sound.play(loops=-1)
            self._status(f"🔁 {os.path.basename(path)}")
        except Exception as e:
            self._status(f"❌ Лупер: {e}")

    def _loop_stop(self):
        if self.loop_sound: self.loop_sound.stop(); self.loop_sound = None

    def _refresh_files(self):
        rec_dir = recordings_path()

        self.fileList.clear()  # ← ВАЖНО

        if os.path.exists(rec_dir):
            for f in sorted(os.listdir(rec_dir)):
                if f.endswith(".wav"):
                    self.fileList.addItem(f)

# ── ВСПОМОГАТЕЛЬНОЕ ───────────────────────────────────────────────────────

    @staticmethod
    def _slider(val=80):
        s = QSlider(Qt.Orientation.Horizontal); s.setRange(0, 100); s.setValue(val); return s

    def _status(self, msg): self.statusBar.setText(msg)

    def _next_tip(self):
        self.tip_idx = (self.tip_idx + 1) % len(TIPS)
        self.tipLabel.setText(TIPS[self.tip_idx])

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Space:
            self.stop() if self.playing else self.play()
        elif e.modifiers() == Qt.KeyboardModifier.ControlModifier:
            {Qt.Key.Key_Z: self.undo,
             Qt.Key.Key_S: self.save_project,
             Qt.Key.Key_D: self.demo}.get(e.key(), lambda: None)()

    def closeEvent(self, e):
        self._loop_stop(); e.accept()

# ── ЗАПУСК ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    init_audio()          # ← ПОСЛЕ QApplication, иначе конфликт на Windows
    w = BeatShare()
    w.show()
    sys.exit(app.exec())